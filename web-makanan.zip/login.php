<?php
session_start();
include 'koneksi.php';

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $query);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user['password'])) {
        session_regenerate_id(true);
        $_SESSION['nama'] = $user['nama'];
        header("Location: beranda.php");
        exit;
    } else {
        $error = "Email atau password salah!";
    }
}
?>

<link rel="stylesheet" href="style.css">

<div class="container">
    <div class="food-icon">🍔</div>
    <h2>LOGIN</h2>
    <p>login terlebih dahulu untuk memesan makanan</p>

    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>

    <form method="POST">
        <input type="email" name="email" placeholder="Email"><br>
        <input type="password" name="password" placeholder="Password"><br>
        <button type="submit" name="login">Login</button>
    </form>

    <p>Belum punya akun? <a href="register.php">Daftar</a></p>
</div>