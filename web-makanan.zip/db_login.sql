-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 27, 2026 at 07:37 AM
-- Server version: 8.4.3
-- PHP Version: 8.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_login`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nama`, `email`, `password`) VALUES
(1, 'adrian', 'adrianvall2120@gmail.com', '$2y$10$THphktG62JdYhqDSNqBocOa35Xz55wlLMrB/XL9PM3FPNIp8o6bnG'),
(3, 'vall', 'iannvall@gmail.com', '$2y$10$/rEUuN3gq5xnW0EIHP/tVef1Re0QcNcBlubAGjvyfFKiD7i5esIoG'),
(4, 'airin', 'airindwiputri158@gmail.com', '$2y$10$C.Ljn8HMAMwXR3Ut/XCGVu/3UCISo8LfkCIymj3mL2QFbf8tM8ySS'),
(5, 'elvan', 'ardianelvan21@gmail.com', '$2y$10$hrVtxjf2ysQcJEz.34o8kO8pNGYsIqPXj4XeQbAyGYNNqo1wZQRIu'),
(6, 'shafana', 'shafana21@gmail.com', '$2y$10$1wGa2a7Yx5Otjfdfg6vLju2oBR.mdD5QhrxG.R1YzMJL8Z353h6SK'),
(7, 'iann', 'iann123@gmail.com', '$2y$10$nxJtIzbd34pOury43J2DF.PoZhBjNMgox0BT1MIvKUZBDDG2tsQI2'),
(8, 'danis', 'danis@gmail.com', '$2y$10$yVS2LiquMkg23za5sSZZp.5bKsKQf2BqYDpPceLG40Sbf82EoLsoK'),
(9, 'charly', 'charly@gmail.com', '$2y$10$Yt5bmGpkF2eLEyK0z5rfHeanCjFjtwN4SZNZtf5OvPiubWJKcIQVK');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
