<?php
include 'koneksi.php';

if (isset($_POST['register'])) {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm = $_POST['confirm'];

    if ($password !== $confirm) {
        $error = "Password tidak sama!";
    } else {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        mysqli_query($conn, "INSERT INTO users (nama, email, password)
                             VALUES ('$nama', '$email', '$password_hash')");
        $success = "Registrasi berhasil!";
    }
}
?>

<link rel="stylesheet" href="style.css">

<div class="container">
    <div class="food-icon">🍕</div>
    <h2>Daftar Akun</h2>
    <p>Buat akun untuk mulai pesan makanan</p>

    <?php 
    if (isset($error)) echo "<p style='color:red;'>$error</p>";
    if (isset($success)) echo "<p style='color:green;'>$success</p>";
    ?>

    <form method="POST">
        <input type="text" name="nama" placeholder="Nama"><br>
        <input type="email" name="email" placeholder="Email"><br>
        <input type="password" name="password" placeholder="Password"><br>
        <input type="password" name="confirm" placeholder="Confirm Password"><br>
        <button type="submit" name="register">Daftar</button>
    </form>

    <p>Sudah punya akun? <a href="login.php">Login</a></p>
</div>